![Thumbnail template web ecommerce 86](https://github.com/user-attachments/assets/7b72ba26-7d8a-4c9e-8dcf-20fae887f6c5)
