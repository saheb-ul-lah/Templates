![Thumbnail template web admin dashboard 32](https://github.com/user-attachments/assets/ec5bcaf4-fab7-4337-9210-25176ede98ec)
