![Thumbnail template web ecommerce 69](https://github.com/user-attachments/assets/ea597835-8096-4540-9965-cffe0107f665)
