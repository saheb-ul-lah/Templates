![Thumbnail template web admin dashboard 29](https://github.com/user-attachments/assets/c8929b65-4137-4f5d-8b61-f38d00e3a7f4)
