/*! For license information please see clinic-add-patient.js.LICENSE.txt */
"use strict";document.addEventListener("DOMContentLoaded",(function(){window.Dropzone}));