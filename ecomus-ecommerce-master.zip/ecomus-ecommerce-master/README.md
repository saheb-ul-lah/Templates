![Thumbnail template web ecommerce 61](https://github.com/user-attachments/assets/7023d489-4315-449f-ba3b-9de8e3687cbf)
