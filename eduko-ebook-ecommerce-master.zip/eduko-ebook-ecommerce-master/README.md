![Thumbnail template web ecommerce 79](https://github.com/user-attachments/assets/3d4907fc-b9cf-4698-a2bb-fb3aa4b3fd49)
