![Thumbnail template web admin dashboard 33](https://github.com/user-attachments/assets/c7c8d1da-69c9-4ffc-84f4-5d021f17b45c)
